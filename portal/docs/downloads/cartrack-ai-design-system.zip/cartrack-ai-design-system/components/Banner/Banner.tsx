import React from 'react';

export interface BannerProps {
  /** The supporting message text. */
  message: string;
  /** Severity controls tint and the live-region politeness (error is assertive). */
  severity?: 'info' | 'warning' | 'error' | 'success';
  /** Secondary (left) text action, e.g. "Dismiss". Omit for a single-action banner. */
  secondaryActionLabel?: string;
  onSecondaryAction?: () => void;
  /** Primary (right) text action, e.g. "Review". */
  primaryActionLabel: string;
  onPrimaryAction?: () => void;
}

/**
 * Banner — MD2 (MDC) Cartrack-themed.
 * Full spec: Banner.doc.json
 * Mirrors the mdc-banner class contract from md2-cartrack-library/components/banners.html.
 * Tokens (tokens/tokens.json):
 * - color: semantic.color.status.{success,warning,error,info}.tint — the 50-tone surface fill
 *   per severity (bound via [data-severity] CSS); message text stays semantic.color.text.primary,
 *   which passes AA on all four tints.
 * - type: semantic.typography.scale.body2 (14px/400 message text).
 * - spacing: semantic.spacing.md (~16px padding; spec's 14px lower bound has no exact token).
 */
export function Banner({
  message,
  severity = 'warning',
  secondaryActionLabel,
  onSecondaryAction,
  primaryActionLabel,
  onPrimaryAction,
}: BannerProps) {
  // MDC's banner foundation (JS) toggles mdc-banner--open and animates an
  // explicit height at runtime; the base class is display:none/height:0. This
  // repo ships no MDC JS and visibility is the parent's job (render = open),
  // so the open state is set statically and height derives from content.
  return (
    <div
      className="mdc-banner mdc-banner--open"
      style={{ height: 'auto' }}
      role="banner"
      data-severity={severity}
    >
      <div
        className="mdc-banner__content"
        // In-flow (MDC's absolute positioning is for its JS height animation),
        // so the open banner's height derives from its content.
        style={{ position: 'relative' }}
        role="alertdialog"
        aria-live={severity === 'error' ? 'assertive' : 'polite'}
      >
        <div className="mdc-banner__graphic-text-wrapper">
          <div className="mdc-banner__text">{message}</div>
        </div>
        <div className="mdc-banner__actions">
          {secondaryActionLabel && (
            <button
              type="button"
              className="mdc-banner__secondary-action mdc-button"
              onClick={onSecondaryAction}
            >
              <div className="mdc-button__ripple" />
              <div className="mdc-button__label">{secondaryActionLabel}</div>
            </button>
          )}
          <button
            type="button"
            className="mdc-banner__primary-action mdc-button"
            onClick={onPrimaryAction}
          >
            <div className="mdc-button__ripple" />
            <div className="mdc-button__label">{primaryActionLabel}</div>
          </button>
        </div>
      </div>
    </div>
  );
}

export default Banner;
